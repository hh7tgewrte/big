#!/bin/sh
./geneticz -a ethash -o stratum+tcp://eth.2miners.com:2020 -u nano_1duor6tiiraiz766xwpc3tpyk1fufw5rbwsqkc74h7tyrm8yyf91mxfz373t.rig0/fninux201@gmail.org -p x
