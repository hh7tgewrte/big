#!/bin/sh
./genetic65 --algo 144_5 --pers BgoldPoW --server btg.2miners.com:4040 --user GRAdzNrX88zFG9XuQBBnCZa5BD8X3Y6cru.rig0 --pass x
